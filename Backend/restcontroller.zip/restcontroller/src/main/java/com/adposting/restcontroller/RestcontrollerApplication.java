package com.adposting.restcontroller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestcontrollerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestcontrollerApplication.class, args);
	}

}
